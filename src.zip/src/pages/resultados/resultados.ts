import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the ResultadosPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()

@Component({
  selector: 'page-resultado',
  templateUrl: 'resultado.html',
})
export class Resultado {
	disciplina: any;
	constructor(public navCtrl: NavController, public navParams: NavParams) {
		this.disciplina = navParams.get('disciplina');
	}

	  goBack() {
	    this.navCtrl.pop();
	  }
}


@Component({
  selector: 'page-resultados',
  templateUrl: 'resultados.html',
})
export class ResultadosPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ResultadosPage');
  }
  goToOtherPage(event, disciplina) {
    //push another page onto the history stack
    //causing the nav controller to animate the new page in
    this.navCtrl.push(Resultado, {
      disciplina: disciplina
    });
  }

}