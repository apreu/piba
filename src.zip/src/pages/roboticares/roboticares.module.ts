import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RoboticaresPage } from './roboticares';

@NgModule({
  declarations: [
    RoboticaresPage,
  ],
  imports: [
    IonicPageModule.forChild(RoboticaresPage),
  ],
})
export class RoboticaresPageModule {}
