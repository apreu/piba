import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {LoginPage} from '../login/login';
import {AnahuacPage} from '../anahuac/anahuac';

import { Injectable } from '@angular/core';

@Injectable()
export class SessionService {

    private loggedIn: boolean = false;

    

    constructor() {
      this.loggedIn = window.localStorage.getItem("loggedIn")=="true" ? true: false;
    }

    isLoggedIn():boolean{
        return this.loggedIn;
    }

    setLoggedIn(isLoggedIn: boolean){
        this.loggedIn = isLoggedIn;
    }
}

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  providers: [SessionService]
})
export class HomePage {

  public anahuacPage = AnahuacPage;
  constructor(public navCtrl: NavController, public sessionService: SessionService) {
    let a = this.sessionService.isLoggedIn();
  	if(!a) this.navCtrl.setRoot(LoginPage);
  }
  push(page) {
    this.navCtrl.push(page);
  }

}
