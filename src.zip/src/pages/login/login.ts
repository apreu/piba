import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import {HomePage} from '../home/home';

import { Injectable } from '@angular/core';
import { ModalController } from 'ionic-angular';
import { ModalLoginPage } from './modal-login.component';
import { AlertController } from 'ionic-angular';



export interface Registro {
  Nombre: string,
  Apellido_Paterno: string,
  Apellido_Materno: string,
  Email: string,
  Celular: string,
  Tipo_Persona: number,
  Estado: string,
  Ciudad: string,
  Uuid: string,
}
export interface Resultado {
  result: boolean,
  errorMsg: string,
  resultCode: number,
  payload: string,
  token: string
}


/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {

  public colegios: any = 
  [
    {
      "DESCR": " BERTA VON GLUMER"
    }, {
      "DESCR": " FLORIDA ATLANTIC UNIVERSITY"
    }, {
      "DESCR": " PUE. COL.ALEMAN A.V. HUMBOLT"
    }, {
      "DESCR": "( PUE. ) COL.ALEMAN A.V. HUMBOLT"
    }, {
      "DESCR": "( SUR ) COL.ALEMAN A.V. HUMBOLT ( XOCHIMILCO )"
    }, {
      "DESCR": "2 NORTHERN HIGLAND SCHOOL"
    }
  ];
  public registro: Registro;
  public resultado: Resultado;
  public uuid: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, public http: HttpClient, public modalCtrl: ModalController, public alertCtrl: AlertController) {
    this.registro = {
      Nombre: "",
      Apellido_Paterno: "",
      Apellido_Materno: "",
      Email: "",
      Celular: "",
      Tipo_Persona: 1,
      Estado: "",
      Ciudad: "",
      Uuid: "",
    };
    this.http.get("http://sistemas.anahuac.mx/apreuapi/api/GetGuid").subscribe(data => {
        this.uuid = data as any;
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

  registrar(){
    this.registro.Uuid = this.uuid;
    this.http.post('http://sistemas.anahuac.mx/apreuapi/api/PIBA/Registro', this.registro)
      .subscribe(
        data=>{
          console.log(data);
          this.resultado = data as any;
          window.localStorage.setItem('uuid', this.uuid);
          window.localStorage.setItem('loggedIn', "true");
          this.showConfirm();
        }
      );
  }
  showConfirm() {
    let confirm = this.alertCtrl.create({
      title: 'Gracias por registrarte',
      message: 'Haz click en Genial para ir a la aplicación',
      buttons: [
        {
          text: 'Cerrar',
          handler: () => {
            console.log('Disagree clicked');
            this.navCtrl.setRoot(HomePage);
          }
        },
        {
          text: 'Genial',
          handler: () => {
            console.log('Agree clicked');
            this.navCtrl.setRoot(HomePage);
          }
        }
      ]
    });
    confirm.present();
  }

}
