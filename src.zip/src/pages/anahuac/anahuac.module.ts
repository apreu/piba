import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AnahuacPage } from './anahuac';

@NgModule({
  declarations: [
    AnahuacPage,
  ],
  imports: [
    IonicPageModule.forChild(AnahuacPage),
  ],
})
export class AnahuacPageModule {}
