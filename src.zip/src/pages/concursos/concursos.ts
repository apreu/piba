import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the ConcursosPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-concursos',
  templateUrl: 'concursos.html',
})
export class ConcursosPage {

  concursos: Array<{concurso: string, color: string, icono: string}>;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.concursos = [
      { concurso: 'Apóstoles del Siglo XXI', color: this.getRandomColor(), icono: 'apostoles_siglo.png'},
	  { concurso: 'Aprendiendo con la Tecnología', color: this.getRandomColor(), icono: 'aprendiendo_2.png'},
	  { concurso: 'Baile y Coreografía', color: this.getRandomColor(), icono: 'baile_3.png'},
	  { concurso: 'Comunicación con Imaginación', color: this.getRandomColor(), icono: 'comu_4.png'},
	  { concurso: 'Conquistando Valores', color: this.getRandomColor(), icono: 'conquistando_5.png'},
	  { concurso: 'Crea tu Propio Negocio', color: this.getRandomColor(), icono: 'negocio_6.png'},
	  { concurso: 'Creación Literaria', color: this.getRandomColor(), icono: 'creacion_7.png'},
	  { concurso: 'Debate', color: this.getRandomColor(), icono: 'debate_8.png'},
	  { concurso: 'Declamación', color: this.getRandomColor(), icono: 'ss.png'},
	  { concurso: 'Interpretación y Composición Musical', color: this.getRandomColor(), icono: 'interpretacion_9.png'},
	  { concurso: 'Investigadores del Nuevo Milenio', color: this.getRandomColor(), icono: 'investigadores_10.png'},
	  { concurso: 'Líderes Hablan', color: this.getRandomColor(), icono: 'lideres11.png'},
	  { concurso: 'Líderes por la Trascendencia', color: this.getRandomColor(), icono: 'lideres_12.png'},
	  { concurso: 'Matemáticas', color: this.getRandomColor(), icono: 'matematicas_13.png'},
	  { concurso: 'Transcending Science', color: this.getRandomColor(), icono: 'trascending_14.png'}
    ];
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ConcursosPage');
  }
  getRandomColor() {
	  var letters = '0123456789ABCDEF';
	  var color = '#';
	  for (var i = 0; i < 6; i++) {
	    color += letters[Math.floor(Math.random() * 16)];
	  }
	  return color;
  }

}
