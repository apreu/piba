import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { MyApp } from './app.component';
import { HomePage, SessionService } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { ModalLoginPage } from '../pages/login/modal-login.component';
import { ListPage } from '../pages/list/list';
import { ConcursosPage } from '../pages/concursos/concursos';
import { MapaPage } from '../pages/mapa/mapa';
import { RoboticaresPage } from '../pages/roboticares/roboticares';
import { ResultadosPage, Resultado } from '../pages/resultados/resultados';
import { AnahuacPage } from '../pages/anahuac/anahuac';


import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { GoogleMaps } from '@ionic-native/google-maps';
import { Firebase } from '@ionic-native/firebase'; 

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    LoginPage,
    ListPage,
    ConcursosPage,
    MapaPage,
    RoboticaresPage,
    ResultadosPage,
    Resultado,
    ModalLoginPage,
    AnahuacPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    HttpModule,
    HttpClientModule,
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    ConcursosPage,
    MapaPage,
    RoboticaresPage,
    ResultadosPage,
    Resultado,
    LoginPage,
    ModalLoginPage,
    AnahuacPage
  ],
  providers: [
    StatusBar,
    SessionService,
    SplashScreen,
    GoogleMaps,
    Firebase,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
